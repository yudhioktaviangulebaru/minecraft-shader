#version 330 compatibility
// gbuffers_textured_lit: pass-through (see lib/programs/gbuffers_generic)
#define USE_TEXTURE
#define USE_LIGHTMAP
#define USE_ALPHA_TEST

#include "/lib/programs/gbuffers_generic.vsh.glsl"
